## CHART MODULE
  #### src\app\charts



## API INTEGRATION
  1. go to src\app\charts\data-provider.service.ts
  2. Remove the line number 33
  3. Add api in line no 63 (return statement)
